# ArduinoNextSteps

Arduino sketches and other source code for the book [Programming Arduino: Next Steps](https://www.amazon.com/Programming-Arduino-Next-Steps-Sketches/dp/0071830251) by [Simon Monk](http://simonmonk.org).

Place the ArduinoNextSteps folder into your Arduino IDE sketches folder.

![Programming Arduino: Next Steps](https://i2.wp.com/www.simonmonk.org/wp-content/uploads/2013/08/cover-for-review.jpg?resize=354%2C540)
