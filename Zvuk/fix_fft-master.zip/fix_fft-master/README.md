# fix_fft
Fix_fft library

Repo for the fix_fft Fast Fourier Transform library.
The implemetantion of this library is not mine, this is how I found it online.
I will only update it so it can be used under current compiler standards.
